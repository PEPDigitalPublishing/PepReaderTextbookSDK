# PEPPlayer

[![CI Status](http://img.shields.io/travis/RavenKite/PEPPlayer.svg?style=flat)](https://travis-ci.org/RavenKite/PEPPlayer)
[![Version](https://img.shields.io/cocoapods/v/PEPPlayer.svg?style=flat)](http://cocoapods.org/pods/PEPPlayer)
[![License](https://img.shields.io/cocoapods/l/PEPPlayer.svg?style=flat)](http://cocoapods.org/pods/PEPPlayer)
[![Platform](https://img.shields.io/cocoapods/p/PEPPlayer.svg?style=flat)](http://cocoapods.org/pods/PEPPlayer)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

PEPPlayer is available through [CocoaPods](http://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod "PEPPlayer"
```

## Author

李沛倬, lipeizhuo0528@outlook.com

## License

PEPPlayer is available under the MIT license. See the LICENSE file for more info.
