//
//  PDFReaderSDKTextBook.h
//  PDFReaderSDKTextBook
//
//  Created by 李沛倬 on 2018/3/6.
//  Copyright © 2018年 pep. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PDFReaderSDKTextBook.
FOUNDATION_EXPORT double PDFReaderSDKTextBookVersionNumber;

//! Project version string for PDFReaderSDKTextBook.
FOUNDATION_EXPORT const unsigned char PDFReaderSDKTextBookVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PDFReaderSDKTextBook/PublicHeader.h>


#import "PEPReaderTextBookManager.h"
#import "PEPTextbookViewController.h"
#import "PEPTextBookBaseVC.h"



