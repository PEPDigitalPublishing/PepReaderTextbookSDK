//
//  PEPTextbookViewController.h
//  PEPDigitalTextBook
//
//  Created by PEP on 2017/10/24.
//  Copyright © 2017年 PEP. All rights reserved.
//

#import "PEPTextBookBaseVC.h"

@interface PEPTextbookViewController : PEPTextBookBaseVC

- (void)setMytextBookAddItem;

- (void)setMyTextBookCancelItem;

- (void)setMyTextBookNavItem;

@end
