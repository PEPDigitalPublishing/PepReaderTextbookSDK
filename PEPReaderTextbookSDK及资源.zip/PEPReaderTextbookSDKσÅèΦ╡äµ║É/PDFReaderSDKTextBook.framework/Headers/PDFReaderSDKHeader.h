//
//  PDFReaderSDKHeader.h
//  PDFReaderSDK
//
//  Created by 李沛倬 on 2018/3/6.
//  Copyright © 2018年 pep. All rights reserved.
//

#ifndef PDFReaderSDKHeader_h
#define PDFReaderSDKHeader_h

// MARK: - Common

#import "PEPToast.h"
#import "PEPSpotlightView.h"


/** 以下预编译指令代码块用于区分【人教点读Target】和【数字教材Target】 */
#ifdef PDFReaderSDKDiandu
// 人教点读
#elif PDFReaderSDKTextbook
// 数字教材
#elif PDFReaderSDKTextbookHB
// 数字教材-河北
#else
// 其他
#endif



#endif /* PDFReaderSDKHeader_h */







