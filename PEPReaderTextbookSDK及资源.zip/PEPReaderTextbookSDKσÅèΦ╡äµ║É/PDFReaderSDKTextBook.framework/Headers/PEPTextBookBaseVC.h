//
//  PEPTextBookBaseVC.h
//  PEPDigitalTextBook
//
//  Created by PEP on 2017/5/11.
//  Copyright © 2017年 凌小惯. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "AppDelegate.h"
#import "MBProgressHUD+PEP.h"

@interface PEPTextBookBaseVC : UIViewController

//@property(nonatomic, strong) AppDelegate *appDelegate;

/**
 滚动视图,添加子视图,请添加在scrollView上,如果需要添加到view上,请调用removeScrollView.
 */
@property(nonatomic, strong) UIScrollView *scrollView;


/**
 移除滚动视图,移除后scrollView相关设置无效,默认为NO
 */
@property(nonatomic, assign) BOOL removeScrollView;


/**
 设置是否隐藏tabbar,默认为NO
 */
@property(nonatomic, assign) BOOL shouldHideTabbar;


/**
 设置视图是否可滚动,默认为YES
 */
@property(nonatomic, assign) BOOL scrollEnabled;


/**
 设置背景色

 @param bgColor 背景色
 */
- (void)setBackgroudColor:(UIColor *)bgColor;


///**
// 屏幕发生旋转时调用
//
// */
//- (void)statusBarOrientationChange;


///**
// 返回按钮点击事件
//
// @param sender 按钮
// */
//- (void)handleBackButton:(id)sender;


///**
// 导航条返回事件(默认返回上一级)
// */
//- (void)back;



/**
 只有一个按钮的Alert（无取消按钮）

 @param title 标题
 @param message 提示文本
 @param buttonTitle 按钮标题
 */
- (void)showAlertWithTitle:(NSString *)title message:(NSString *)message buttonTitle:(NSString *)buttonTitle;

/**
 单个按钮提示框

 @param message 提示框文字
 */
- (void)showAlertViewByMessage:(NSString *)message;


/**
 带标题的提示框

 @param message 提示文字
 @param title 标题
 */
- (void)showAlertViewByMessage:(NSString *)message title:(NSString *)title;


/**
 可定制按钮提示框

 @param title 标题
 @param message 内容
 @param firstTitle 第一个按钮标题
 @param fristHandler 第一个按钮触发事件
 @param secondTitle 第二个按钮标题
 @param secondHandler 第二个按钮触发事件
 */
- (void)showAlertViewByTitle:(NSString *)title message:(NSString *)message
               firstBtnTitle:(NSString *)firstTitle fristHandler:(void (^)(UIAlertAction *action))fristHandler
              secondBtnTitle:(NSString *)secondTitle secondHandler:(void (^)(UIAlertAction *action))secondHandler;


/**
 显示普通提示框

 @param tip 提示语
 */
- (void)showNormalText:(NSString *)tip;
- (void)showNormalText:(NSString *)tip hideAfterDelay:(NSTimeInterval)afterDelay;


/**
 隐藏加载
 */
- (void)hideHudLoading;

/**立即隐藏Loading视图*/
- (void)immediatelyHideHudLoading;


/**
 显示加载

 @param tip 加载标题
 */
- (void)showHudLoading:(NSString *)tip;


/**
 加载成功

 @param tip 成功提示语
 */
- (void)showHudSuccess:(NSString *)tip;


/**
 加载失败

 @param tip 失败提示语
 */
- (void)showHudFailure:(NSString *)tip;


/**
 加载成功后回调事件

 @param tip 成功标题
 @param aSelector 触发事件
 @param obj 参数
 */
- (void)showHudSuccess:(NSString *)tip withSelector:(SEL)aSelector withObject:(id)obj;


/**
 加载失败后的回调事件 

 @param tip 失败标题
 @param aSelector 触发事件
 @param obj 参数
 */
- (void)showHudFailure:(NSString *)tip withSelector:(SEL)aSelector withObject:(id)obj;

@end
