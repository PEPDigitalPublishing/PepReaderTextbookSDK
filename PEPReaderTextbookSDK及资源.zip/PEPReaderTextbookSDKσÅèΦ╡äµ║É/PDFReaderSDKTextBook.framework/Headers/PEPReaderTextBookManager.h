//
//  PEPReaderTextBookManager.h
//  PDFReaderSDKTextBook
//
//  Created by pep_han on 2018/6/25.
//  Copyright © 2018年 pep. All rights reserved.
//

#import <Foundation/Foundation.h>


typedef void(^CompleteBlock) (id response);


@interface PEPReaderTextBookManager : NSObject


//single_interface(PEPReaderTextBookManager)

/**
 PEPReaderTextBookManager 实例化

 @return PEPReaderTextBookManager 单例对象
 */
+ (instancetype)shareManagerWithAPPID:(NSString *)APPID;


/**
 设置SDK的BaseUrl

 @param URLString kBaseUrl
 */
- (void)setBaseURL:(NSString *)URLString ;

/**
 得到书本权限的信息

 @param dic {username:用户名,password:密码}
 */
- (void)getUserAuthWithParam:(NSDictionary *)dic;


/**
 查询教材列表

 @param dic 请求参数{rkxd:学段,zxxkc:学科,nj:年级,name:教材名称(支持模糊搜索),pageno:分页页码(int 默认1),pagesize:分页大小(int 默认10),detail:是否返回详情(String类型,true/false;默认false不返回)}   参数皆为非必需
 @param finished 成功/失败完成后回调
 */
- (void)queryTextbookListWithParam:(NSDictionary *)dic withBlock:(CompleteBlock)finished;



/**
 查询教材详情

 @param dic 请求参数{id:教材ID(String,必需),chapter:是否返回章节(String类型,true/false;默认false不返回)}
 @param finished 成功/失败完成后回调
 */
- (void)queryTextbookDetailWithParam:(NSDictionary *)dic withBlcok:(CompleteBlock)finished;



/**
 退出垂直平台 清除用户信息
 */
- (void)quitCZPTuserAccount;


//+ (void)getBookList;

@end
