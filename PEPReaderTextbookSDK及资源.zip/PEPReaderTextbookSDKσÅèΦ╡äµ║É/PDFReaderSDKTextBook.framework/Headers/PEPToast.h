//
//  PEPToast.h
//  PDFReaderSDK
//
//  Created by 李沛倬 on 2018/3/19.
//  Copyright © 2018年 pep. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PEPToast : NSObject

/**
 显示文本提示框(Toast)。可手动设置显示的视图和隐藏时间
 
 @param message 需要显示的信息
 @param inView 需要将toast添加到哪个视图上，如果为空则会添加到keyWindow上
 @param delayHidden 多久之后隐藏，单位为秒。如果为0会自动根据内容长度决定多久之后隐藏
 */
void showPEPToastInView(id message, UIView *inView, NSTimeInterval delayHidden);

void showPEPToastDelayHidden(id message, NSTimeInterval delayHidden);

void showPEPToast(id message);


// MARK: - Translate
void showReadingTranslateToast(id message);

void hideReadingTranslateToast(void);


@end
