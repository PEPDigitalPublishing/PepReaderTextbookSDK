//
//  PEPSpotlightView.h
//  PDFReaderSDKDiandu
//
//  Created by 李沛倬 on 2018/5/11.
//  Copyright © 2018年 pep. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PEPSpotlightView : UIView

/*聚光灯效果*/
#pragma mark - Require

@property(nonatomic, strong) NSArray *rectArray;    //!<多个高亮区域，传rect

#pragma mark - Option

@property(nonatomic, strong) UIColor *darkColor;    //!<聚光灯以外颜色，默认是[UIColor colorWithWhite:0 alpha:0.5]

@property(nonatomic, strong) UIColor *borderColor;  //!<边框颜色，默认为白色

@property(nonatomic, assign) CGFloat lightCornerRadius;    //!<圆角，默认是0

@property(nonatomic, copy) NSString *message;    //!<tip内容

@property (nonatomic, copy) void(^touchBlock)(PEPSpotlightView *view);

@end









