

## 此目录下存放公共类及UI

    若一个功能或UI在人教点读和数字教材中相似或相同，可将相同部分提取到该目录下。
    
    创建公共类步骤：
    1. CMD+N，选择需要创建的类型
    2. 设置类名
    3. 选择文件位置，此时务必将窗口最下方的Targets中的所有勾全部勾上，使这个类同时导入到所有的Target下，具体见PDFReaderSDKDiandu.acassets -> CreateCommonClass
    4. 在各个Target -> Build Phases -> Headers中管理该类是公开（Public）还是私有（Private）


    *关于图片资源，在使用该Framework的项目中（此处为PDFReaderSample）添加Framework同名的Asset Catalog（例如PDFReaderSDKDiandu.xcassets），Framework中需要使用的图片都放到其中*


    *关于其他资源，例如XIB、MP3等，同样在使用该Framework的项目中（此处为PDFReaderSample）添加Framework同名的Bundle，将这些资源放到其中*

